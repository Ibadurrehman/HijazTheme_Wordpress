<?php

 /* Include Style */

function load_stylesheets()
{
    wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), false, 'all' );
    wp_enqueue_style( "bootstrap" );

    wp_register_style( 'style', get_template_directory_uri() . '/css/app.css', array(), false, 'all' );
    wp_enqueue_style( "style" );
}

add_action('wp_enqueue_scripts', 'load_stylesheets');


 /* Include Script */

function load_Scripts()
{
    wp_register_script( 'jsLibrary', get_template_directory_uri() . '/js/jquery-3.5.1.slim.min.js', array(), false, 'all' );
    wp_enqueue_script( "jsLibrary" );

    wp_register_script( 'jsBootstrap', get_template_directory_uri() . '/js/bootstrap.bundle.min.js', array(), false, 'all' );
    wp_enqueue_script( "jsBootstrap" );

    wp_register_script( 'jsCustom', get_template_directory_uri() . '/js/custom.js', array(), false, 'all' );
    wp_enqueue_script( "jsCustom" );
}
add_action('wp_enqueue_scripts', 'load_Scripts');

?>

<!-- Menu Option -->
