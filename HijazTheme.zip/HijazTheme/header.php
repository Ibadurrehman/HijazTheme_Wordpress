<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hijaz Theme</title>
    <!-- Header-->
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<main class="main">
<!--Navigation Menu-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">

</nav>
</main>
    
